<?php
    $db_conn_hostname = "homepages.shu.ac.uk";
    $db_conn_username = "b6019531";
    $db_conn_password = "Babita73";
    $db_name = "b6019531_db1";

?>