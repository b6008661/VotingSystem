
<style>
    img {
        display: block;
        margin-left: auto;
        margin-right: auto;
    }
</style>

<head>


    <title>Something went wrong</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link href="../includes/css/style.css" rel="stylesheet" type="text/css">



</head>


<div style="margin-top: 5%" class="container">
    <h1><img src="../includes/img/error.png" alt="500" width="600" height="400">
        <p>oops, Something went wrong <a href="../home.php" target="_blank">click here</a> to be redirected.

</div>